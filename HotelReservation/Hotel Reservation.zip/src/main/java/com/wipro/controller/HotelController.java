package com.wipro.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import com.wipro.bean.*;
import com.wipro.dao.*;

@Controller
public class HotelController {
	@Autowired
	ReservationDao dao;

	@RequestMapping("PreInsertHotel")
	public ModelAndView preInsert() {
		Hotel hotel = new Hotel();
		hotel.setId(1);
		ModelAndView mv = new ModelAndView("SearchHotel", "hotel", hotel);
		return mv;
	}

	@RequestMapping("GoToConfirmation")
	public ModelAndView checkReservation(@ModelAttribute("hotel") Hotel dept) {
		ModelAndView mv;
		if (dao.searchHotel(dept)) {
			mv = new ModelAndView("Rejection");
		} else {
			mv = new ModelAndView("ConfirmReservation", "hotel", dept);
		}
		return mv;
	}

	@RequestMapping("CheckReservation")
	public ModelAndView goGuestDetails(@ModelAttribute("hotel") Hotel dept) {
		return new ModelAndView("GuestDetails", "hotel", dept);
	}

	@RequestMapping("InsertGuest")
	public ModelAndView goToConfirmation(@ModelAttribute("hotel") Hotel dept) {
		System.out.println(dept.toString());
		ModelAndView mv = new ModelAndView("confirmation", "hotel", dept);
		dao.insertDepatment(dept);
		return mv;
	}

	@RequestMapping("GoBack")
	public ModelAndView goToSearchHotel(@ModelAttribute("hotel") Hotel dept) {
		return new ModelAndView("SearchHotel", "hotel", dept);
	}
}